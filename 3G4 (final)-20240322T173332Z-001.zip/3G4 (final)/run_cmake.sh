cmake -G "Unix Makefiles" -DCMAKE_BUILD_TYPE=Release -B src -Wno-dev
