#include "VulkanWindow.h"

void construct_xz_reslice_linear(VulkanWindow* frame);
void construct_yz_reslice_linear(VulkanWindow* frame);
